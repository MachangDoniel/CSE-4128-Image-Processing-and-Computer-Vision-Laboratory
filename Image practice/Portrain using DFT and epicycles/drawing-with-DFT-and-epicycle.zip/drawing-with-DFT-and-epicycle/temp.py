import matplotlib
print(matplotlib.__version__)
